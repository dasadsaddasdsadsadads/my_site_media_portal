export default function Footer() {
  return (
    <footer className="mt-12">
    </footer>
  );
}
